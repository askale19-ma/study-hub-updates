#!/bin/bash
set -u
app="$1"
transaction="$2"
old_pid="$3"
candidate="$transaction/stage/StudyHub.app"
previous="$transaction/previous.app"
ready="$transaction/ready"
receipt="$4"

result() {
  /usr/bin/printf '%s\n' "$1" > "$receipt.tmp"
  /bin/mv -f "$receipt.tmp" "$receipt"
}

reopen() {
  /usr/bin/open -n "$app"
}

for ((attempt = 0; attempt < 80; attempt++)); do
  /bin/kill -0 "$old_pid" 2>/dev/null || break
  /bin/sleep 0.25
done
if /bin/kill -0 "$old_pid" 2>/dev/null; then
  result "The update stopped because Study Hub did not close. Your current version is still available."
  /bin/rm -rf "$transaction"
  exit 1
fi

if ! /bin/mv "$app" "$previous"; then
  result "The update stopped because the current app could not be moved."
  reopen
  /bin/rm -rf "$transaction"
  exit 1
fi

if /bin/mv "$candidate" "$app" && /usr/bin/open -n "$app" --args --studyhub-update-ready "$ready"; then
  for ((attempt = 0; attempt < 90; attempt++)); do
    if [ -f "$ready" ]; then
      /bin/rm -rf "$transaction"
      exit 0
    fi
    /bin/sleep 1
  done
fi

if [ -e "$app" ] && ! /bin/mv "$app" "$transaction/failed.app"; then
  result "The update could not be rolled back automatically. The previous app is in $previous."
  exit 1
fi
if ! /bin/mv "$previous" "$app"; then
  result "The update could not be rolled back automatically. The previous app is in $previous."
  exit 1
fi
result "The update did not finish starting. Study Hub restored your previous version."
reopen
/bin/rm -rf "$transaction"
exit 1
